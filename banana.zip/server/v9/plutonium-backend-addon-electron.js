// https://github.com/electron/electron/issues/21457#issuecomment-815770296
module.exports = require("electron");
