This directory should contain a copy of the `data` directory from 5etools.
